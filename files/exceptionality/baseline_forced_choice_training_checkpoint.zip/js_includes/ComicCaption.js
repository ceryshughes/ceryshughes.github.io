/* This controller is designed to run AcceptabilityJudgment tasks with comics.*/
/*Modified version of ComicCaption that has bigger buttons (Question2) and a plural option (plural) that triples the image*/

define_ibex_controller({
name: "ComicCaption",

jqueryWidget: {
    _init: function () {
        this.cssPrefix = this.options._cssPrefix;
        this.utils = this.options._utils;
        var face = this.options.face;
        if (true){// face == "human"){
         //face_html = "<img src='http://people.umass.edu/bprickett/Opacity_Denial/PracticeQuestions/human_face_neutral.png'>";
         //If you want faces in the comic caption pages, uncomment the stuff above and comment out the stuff below:
         face_html = "";
        }
        else {
         face_html = "<img src='http://people.umass.edu/bprickett/Opacity_Denial/alien_face_neutral.png'>";   
        }
        
        var meaning = this.options.mean;
        var fullhtml1 = "<img style='display:block;' height=200".concat(" src=\"").concat(this.options.html).concat("\">");//Build full html object from the url provided in items
        //var fullhtml1 = "<td><img".concat("\" src=\"").concat(this.options.html).concat("\"></td>");
        if(this.options.plural == true){
            fullhtml1 = "<td>".concat(fullhtml1).concat("</td>")
            fullhtml1 = "<table><tr>".concat(fullhtml1).concat(fullhtml1).concat(fullhtml1).concat("</tr></table>");
        }
        
        //console.log(fullhtml); //Make sure url is correct
        var opts = {
            options:     this.options,
            triggers:    [2],
            children:    [
                        "Message",
                            {html : fullhtml1,
                            transfer: null,
                            consentRequired: false,
                            cssPrefix: "ComicCaption"+this.options.cssPrefix,},
                        "FlashSentence",
                            {s: this.options.s,
                            timeout: null,
                            audio: this.options.audio,
                            audioMessage: this.options.audioMessage,
                            audioTrigger: this.options.audioTrigger},
                        "Question2",
                            {q:                   this.options.q,
                            as:                  this.options.as,
                            hasCorrect:          dget(this.options, "hasCorrect", false),
                            presentAsScale:      this.options.presentAsScale,
                            presentHorizontally: this.options.presentHorizontally,
                            autoFirstChar:       typeof(this.options.autoFirstChar) == "undefined" ? this.options.presentAsScale : this.options.autoFirstChar,
                            randomOrder:         this.options.randomOrder,
                            showNumbers:         this.options.showNumbers,
                            timeout:             this.options.timeout,
                            instructions:        this.options.instructions,
                            leftComment:         this.options.leftComment,
                            rightComment:        this.options.rightComment,
                            }
                            ]};
        this.element.VBox(opts);
    }
},

properties: {
    obligatory: ["s", "as", "q", "html"],
    htmlDescription:
        function (opts) {
            var m = ibex_controller_get_property("Message", "htmlDescription")(opts);
            var s = ibex_controller_get_property("FlashSentence", "htmlDescription")(opts);
            var q = ibex_controller_get_property("Question2", "htmlDescription")(opts);
            var p =
                $(document.createElement("div"))
                .append(("M: ").append($(m)))
                .append($("<p>").append("Q: ").append($(q)))
                .append("").append($("<b>").text("S:"))
                .append($(s));
             return p;
        }}
});