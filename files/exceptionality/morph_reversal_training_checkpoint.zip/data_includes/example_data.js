//Preload images using Alex Drummond's Preloader controller.
//Stimulus setup using a modification of Brandon Prickett's Experiment 2 code
//Forced choice code modified from test code
//All bugs, errors, and stylistic faux pas can be attributed to Cerys Hughes.

//**************************************
// INITIALIZE VARIABLES AND FUNCTIONS
//***************************************

//Javascript/HTML skeleton for playing audio
var silence_one = "<audio style='display:none;' id='sil_1' controls autoplay onended='audioEndPreA()'><source src='https://brandon-prickett.com/opacity_stimuli/silence_halfSecond.wav'></audio>";
var silence_two = "<audio style='display:none;' id='sil_2' controls onended='audioEndPreB()'><source src='https://brandon-prickett.com/opacity_stimuli/silence_quarterSecond.wav'></audio>";
var player_function_a = "function audioEndPreA() {document.getElementById('a_player').play();}";
var player_function_mid = "function audioEndPostA() {document.getElementById('sil_2').play();}";
var player_function_b = "function audioEndPreB() {document.getElementById('b_player').play();}";
var player_functions = silence_one.concat(silence_two).concat("<script>").concat(player_function_a).concat(player_function_mid).concat(player_function_b).concat("</script>")

//Marking system
const System = {
    p: "plural", //Plural is marked
    s: "singular" //Singular is marked
}

//Conditions:
var set = "b"; //a or b
var prop = "25"; //04, 125, 25 (no decimals!)

//Other params:
//TODO: double these
var train_trials = 598; //Should be 299 in real exp.
var test_trials = 24; //Should be 24 in real exp.
var post_trials = 24; //Should be 24 in real exp.
var break_every = 50; //Should be 50 in real exp.
    

//Visual stimuli  
//if (set == "a"){
//  var pic_names = [
//                   4, 8, 10, 3, 12,
//                   19, 2, 6, 11, 13,
//                   15, 18, 1, 5, 7,
//                   9, 14, 16, 17, 20,
//                   21, 22, 23, 24
//                  ];  
//}
//if (set == "b"){
  //var pic_names = [
  //                 2, 6, 11, 13, 15,
  //                 18, 4, 8, 10, 3,
  //                 12, 19, 1, 5, 7,
  //                 9, 14, 16, 17, 20,
  //                 21, 22, 23, 24
  //                ];
//}
  
 //Mapping from stem IDs (equivalent to A indices) to picture IDs in A and B lists                      
var pic_ids = new Map([
                       [0, {a:4, b:17}],
                       [1, {a:8, b:20}],
                       [2, {a:10, b:21}],
                       [3, {a:3, b:22}],
                       [4, {a:12, b:23}],
                       [5, {a:19, b:24}],
                       [6, {a:2, b:2}],
                       [7, {a:6, b:6}],
                       [8, {a:11, b:11}], 
                       [9, {a:13, b:13}],
                       [10, {a:15, b: 15}],
                       [11, {a:18, b:18}],
                       [12, {a:1, b:4}],
                       [13, {a:5, b:8}],
                       [14, {a:7, b:10}],
                       [15, {a:9, b:13}],
                       [16, {a:14, b:12}],
                       [17, {a:16,b:19}],
                       [18, {a:17, b:1}],
                       [19, {a:20, b:5}],
                       [20, {a:21, b:7}],
                       [21, {a:22, b:9}],
                       [22, {a:23, b:14}],
                       [23, {a:24, b:16}]
                       ]);
  
                     
                       
                       
                       

//Functions
function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    let j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

function get_img(stem_num) {
    var pic_dir = "https://people.umass.edu/bprickett/exceptionality2/";
    if(set == "a"){
        var label = pic_ids.get(stem_num).a;
            }
    else{
        var label = pic_ids.get(stem_num).b;
            }
    
    return pic_dir.concat("train_").concat(set).concat("_").concat(label).concat(".png")
}
 
 //stem_num: number corresponding to stem in stem_ids
 //marked: boolean, true if marked, false if bare
 //returns name of audio file
function get_audio(stem_num, marked){
    bn = "https://ceryshughes.github.io/files/exceptionality/"
    if(marked){
        fn = "train_fi_"
    }else{
        fn = "train_stem_"
    }
    //if ([12,13,14,15,16,17].indexOf(stem_num) != -1){ //Stems with missing -fi forms
   //     return 'https://brandon-prickett.com/opacity_stimuli/silence_quarterSecond.wav'
    //}else{
    return bn + fn + stem_num.toString() + ".wav"
    //}
}
 
   
//**************************************
// BUILD TRAINING TRIALS
//***************************************
//Visual stimuli  
//CH: Where are the pic names from?


//Suffixes
//CH: change to bare vs fi instead of ku vs fi
//Singulative lexical item: singular suffix is "fi", plural suffix is ""
//Plural-marking lexical item: singular suffix is "", plural suffix is "fi"
if (prop == "04"){
     var systems = [
                       System.p,   System.s,   System.s,    System.s,
                       System.s,    System.s,    System.s,    System.s,
                       System.s,    System.s,    System.s,    System.s,
                       System.s,    System.s,    System.s,    System.s,
                       System.s,    System.s,    System.s,    System.s,
                       System.s,    System.s,    System.s,    System.s
                   ];   
}
if (prop == "125"){
     var systems = [
                       System.p,   System.p,   System.p,    System.p,
                       System.s,    System.s,    System.s,    System.s,
                       System.s,    System.s,    System.s,    System.s,
                       System.s,    System.s,    System.s,    System.s,
                       System.s,    System.s,    System.s,    System.s,
                       System.s,    System.s,    System.s,    System.s
                   ];    
}
if (prop == "25"){
    var systems = [
                       System.p,   System.p,   System.p,    System.p,
                       System.p,    System.p,    System.s,    System.s,
                       System.s,    System.s,    System.s,    System.s,
                       System.s,    System.s,    System.s,    System.s,
                       System.s,    System.s,    System.s,    System.s,
                       System.s,    System.s,    System.s,    System.s
                   ];
}

//Construct plural suffixes: the opposite of the singular suffixes
var sys_switch = {"plural":"singular", "singular": "plural"};

//console.log(singular_suffixes)
//console.log(plural_suffixes)
    
stem_ids = [ "marel", "drokra", "pisfu", "glakod", "mafdi",
                  "blezan", "trapla", "vidfo", "same", "truvit",
                  "kisal", "tutun", "lugat", "fudki", "freglu",
                  "tikle", "gazal", "flebon", "dosid", "zakta",
                  "gragol", "krakle", "tazku", "brugan"
                 ];

//Stems
if (set == "a"){
    var words = [ stem_ids.indexOf("marel"), stem_ids.indexOf("drokra"), stem_ids.indexOf("pisfu"), stem_ids.indexOf("glakod"),
    stem_ids.indexOf("mafdi"),
                  stem_ids.indexOf("blezan"), stem_ids.indexOf("trapla"), stem_ids.indexOf("vidfo"), stem_ids.indexOf("same"), stem_ids.indexOf("truvit"),
                  stem_ids.indexOf("kisal"), stem_ids.indexOf("tutun"), stem_ids.indexOf("lugat"), stem_ids.indexOf("fudki"), stem_ids.indexOf("freglu"),
                  stem_ids.indexOf("tikle"), stem_ids.indexOf("gazal"), stem_ids.indexOf("flebon"), stem_ids.indexOf("dosid"), stem_ids.indexOf("zakta"),
                  stem_ids.indexOf("gragol"), stem_ids.indexOf("krakle"), stem_ids.indexOf("tazku"), stem_ids.indexOf("brugan")
                 ];
}
if (set == "b"){
    //CH: use marking_switch
    //var suff_switch = {"":"fi", "fi":""};
    var words = [
                 stem_ids.indexOf("trapla"), stem_ids.indexOf("vidfo"), stem_ids.indexOf("same"), stem_ids.indexOf("truvit"), stem_ids.indexOf("kisal"),
                 stem_ids.indexOf("tutun"), stem_ids.indexOf("lugat"), stem_ids.indexOf("fudki"), stem_ids.indexOf("freglu"), stem_ids.indexOf("tikle"),
                 stem_ids.indexOf("gazal"), stem_ids.indexOf("flebon"), stem_ids.indexOf("dosid"), stem_ids.indexOf("zakta"), stem_ids.indexOf("gragol"),
                 stem_ids.indexOf("krakle"), stem_ids.indexOf("tazku"), stem_ids.indexOf("brugan"), stem_ids.indexOf("marel"), stem_ids.indexOf("drokra"),
                 stem_ids.indexOf("pisfu"), stem_ids.indexOf("glakod"), stem_ids.indexOf("mafdi"), stem_ids.indexOf("blezan")
                 ];
    
    //CH: Switch singular and plural markings for set b! (This is equivalent to switching singular suffixes and plural suffixes?)
    for (var s = 0; s < systems.length; s++){
           systems[s] = sys_switch[systems[s]];
        
        
    }
}
for (var i = 0; i < words.length; i++){
    console.log(i, stem_ids[i])
}



//CH TODO: adapt filenames to morphological reversal; we just want the /fi/ ones
//Audio stimuli
//var sing_audios = [];
//var plur_audios = [];
//var all_audios = "";
//for (var i = 1; i <= 24; i ++){
//    this_sa = stim_dir.concat("train_").concat(set).concat(prop).concat("_sing_").concat(i).concat(".wav"); //Unmarked
//    this_pa = stim_dir.concat("train_").concat(set).concat(prop).concat("_plur_").concat(i).concat(".wav"); //Marked. We just want the /fi/ ones
//    sing_audios.push(this_sa);
//    plur_audios.push(this_pa);

    //CH: randomize this
//    all_audios = all_audios + "<audio style='display:none;' preload><source src='"+this_sa+"' type='audio/wav'></audio>" + "<audio style='display:none;' preload><source src='"+this_pa+"' type='audio/wav'></audio>";
//}


//Create a randomly ordered list of tokens with the appropriate frequencies:
var freqs = [
              13, 5, 20, 10, 16,
              11, 40, 7, 6, 4,
              8, 26, 7, 4, 79,
              9, 6, 5, 5, 4,
              4, 4, 3, 3
            ];
var tokens = [];
for (var i = 0; i < freqs.length; i++){
     for (var j = 0; j < freqs[i]; j++){
         //Separate plurals and singulars so they can be shuffled apart
         //TODO: add audio and picture
         //tokens.push(words[i]+","+suffixes[i]+","+pics[i]+","+stem_audios[i]+","+plur_audios[i]);
         tokens.push(stem_ids[words[i]]+","+systems[i]+","+ System.p) //Add plural word
         tokens.push(stem_ids[words[i]]+","+systems[i]+"," + System.s) //Add singular word

     }   
}
shuffle(tokens);


//Arrays to build:
var train_names = [];
var train_items = [];
train_trials = tokens.length
var total_breaks = Math.floor((train_trials+1)/break_every);
for (var trial_num = 0; trial_num < train_trials; trial_num++){
    //Quantity: singular or plural
    [stem, sys, quantity] = tokens[trial_num].split(",");
    console.log(tokens[trial_num])
    
    var marked_audio = get_audio(stem_ids.indexOf(stem), true)  
    var bare_audio = get_audio(stem_ids.indexOf(stem), false)  
    
    if(sys == quantity){
        //If it's a singulative system and singular word, mark.
        //If it's a plural system and plural word, mark.
        var correct = stem + "fi"     
        var wrong = stem
        var correct_audio = marked_audio
        var wrong_audio = bare_audio          
    }else{
    //Otherwise, no suffix.
        var correct = stem   
        var wrong = stem + "fi"
        var correct_audio = bare_audio
        var wrong_audio = marked_audio
    }
       
    var feedback_audio = "<audio autoplay><source src='".concat(correct_audio).concat("'>Error! Please contact researcher.</audio>");
    
    //Randomize order: generate number in [0,1]
    coin = Math.floor(Math.random() * (1 - 0 + 1))
    if (coin > 0.50){
        var ordered_options = [correct, wrong]
        var a_audio = correct_audio
        var b_audio = wrong_audio
        var correct_audio_order = "a"
        
    }else{
        var ordered_options = [wrong, correct]
        var a_audio = wrong_audio
        var b_audio = correct_audio
        var correct_audio_order = "b"
    }   
    console.log(a_audio, b_audio)
    //Build question HTML
    audio_a = "<audio style='display:none;' id='a_player' controls onended='audioEndPostA()'><source src='"+a_audio+"'></audio>"
    audio_b = "<audio style='display:none;' id='b_player'><source src='"+b_audio+"'></audio>";
    
    //var pic_html = "<img src='".concat(picture).concat("'>");
    //var stem_audio_html = "<audio autoplay><source src='".concat(stem_audio).concat("'>Error! Please contact researcher.</audio>");
    //var plur_audio_html = "<audio autoplay><source src='".concat(plur_audio).concat("'>Error! Please contact researcher.</audio>");
    
    
    myQ = player_functions + "<p> Choose the word for this picture </p><br><br><br>" +
                       "<table align='center'><tr><td><span style='visibility:hidden;'>__</span><span id='option_A'>"+
                       "</span></td><td><p style='visibility:hidden;'>__</p></td><td><span style='visibility:hidden;'>"+
                       "__</span><span id='option_B'></span></td></tr></table>" +
                       audio_a + audio_b;
    console.log(myQ)
    
    //Forced choice
    var train_name = "train_stem_"+trial_num+"_"+quantity;
    train_items.push([train_name, "ComicCaption", {s:"", q:myQ, html:get_img(stem_ids.indexOf(stem)), plural: quantity == System.p ? true : false, 
        as: ordered_options, presentHorizontally:true, randomOrder:false, hasCorrect:correct}]);
    train_names.push(train_name);
    
        
        
    //Teach participants the stem:
    //var stem_html = pic_html.concat("<br><br><table><tr><td colspan='3'>The word for the above picture is:</td></tr><tr><td></td><td style='text-align:center;'><h2 style='align:center;'>").concat(stem).concat("</h2></td><td></td></tr></table>").concat(stem_audio_html);
    //train_items.push(["train_stem_"+trial_num, "my_Message", {html:stem_html, transfer:2000}]);
    //train_names.push("train_stem_"+trial_num);
    
    //Ask participants the plural:
    //var plural_pic = "<tr><td>".concat(pic_html).concat("</td><td>").concat(pic_html).concat("</td><td>").concat(pic_html).concat("</td></tr>");
    //var plural_html = "<table>".concat(plural_pic).concat("<tr>").concat("<td colspan='3' style='text-align:center;'><br>What’s the word for the above picture?</td></tr><tr><td></td><td><br><input type='text' name='train_answer_"+trial_num+"' id='train_answer_box_"+trial_num+"' class='obligatory'></td><td></td></tr></table><script>document.getElementById('train_answer_box_"+trial_num+"').focus();</script>");
    //train_items.push(
    //                  [
    //                      "train_plural_"+trial_num,
    //                       "my_Form",
    //                       {
    //                           html:plural_html,
    //                           continueOnReturn:true,
    //                           answer:stem.concat(suffix),
    //                           continueMessage: "Click here or press ENTER to continue..."
    //                        }
    //                    ]
    //               );
    //train_names.push("train_plural_"+trial_num);
                                                              
    
    
    //Give feedback:
    //if (correct_audio_order == "a"){
    //    var feedback_html = audio_a;
//        var feedback_script = "<script>"+player_function_a+"</script>";
           
 //   }else{
 //       var feedback_html = audio_b;
 //       var feedback_script = "<script>"+player_function_b+"</script>";
 //   }
 //   var feedback = feedback_script + feedback_html
    train_items.push([
                       "train_feedback"+trial_num,
                       "my_Separator2",
                       {
                           //normalMessage:"<table>"+plural_pic+"<tr><td colspan='3' style='text-align:center;'><br><h1 style='display:inline;font-size:3em;'>✔</h1><h1 style='display:inline;'>"+stem+suffix+"</h1></td></tr></table>"+plur_audio_html,
                           //errorMessage:"<table>"+plural_pic+"<tr><td colspan='3' style='text-align:center;'><br><h1 style='display:inline;font-size:3em;'>✘</h1><h1 style='display:inline;'>"+stem+suffix+"</h1></td></tr></table>"+plur_audio_html,
                           normalMessage:"<table>"+"<tr><td colspan='3' style='text-align:center;'><br><h1 style='display:inline;font-size:3em;'>✔</h1><h1 style='display:inline;'>"+correct+"</h1></td></tr></table>" + feedback_audio,
                           errorMessage:"<table>"+"<tr><td colspan='3' style='text-align:center;'><br><h1 style='display:inline;font-size:3em;'>✘</h1><h1 style='display:inline;'>"+correct+"</h1></td></tr></table>" + feedback_audio,
                        
                           transfer:2000,
                           ignoreFailure: false
                       }
    ]),
    train_names.push("train_feedback"+trial_num);
    
    if (((trial_num+1) % break_every == 0) && (trial_num+1 != train_trials)){               
        break_num = (trial_num+1)/break_every;
        train_items.push(["train_break_"+break_num, "my_Message", {html:"<h1>Optional Break</h1><p>Great work! You’re "+break_num+"/"+total_breaks+" of the way through the Language Learning Phase. Feel free to take a break now if you need one.</p><br><br><p><i>Press any key to continue.</i>", transfer:"keypress"}]);
        train_names.push("train_break_"+break_num);
    }
        
            
}

         
var items = train_items;
var shuffleSequence = seq(...train_names)
        

